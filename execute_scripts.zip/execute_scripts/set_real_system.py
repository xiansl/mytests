#!/usr/bin/env python
# -*- coding:utf-8 -*-
#
#   Author  :   Zhuang Di ZHU
#   E-mail  :   zhuangdizhu@yahoo.com
#   Date    :   15/09/11 12:34:13
#   Desc    :
#
from __future__ import division
import sys
import numpy
import random
from mysql.connector import MySQLConnection,Error
from python_mysql_dbconfig import read_db_config

class SystemInitiator(object):
    def __init__(self):
        self.dbconfig = read_db_config()
        self.conn = MySQLConnection(**self.dbconfig)
        self.acc_type_list = dict()
        self.total_node_num = 2
        self.fpga_node_num = 1
        self.each_section_num = 4
        self.url_port = "8000"
        self.acc_type_list['AES'] = '1.2'
        self.acc_type_list['DTW'] = '1.2'
        self.acc_type_list['EC'] = '1.2'
        self.acc_type_list['FFT'] = '1.2'
        self.acc_type_list['SHA'] = '0.15'


    def create_acc_table(self):
        cursor = self.conn.cursor()
        try:
            query1 = "DROP TABLE IF EXISTS `acc_type_list`"
            query2 = "CREATE TABLE `acc_type_list` ("\
                    "`id` int(11) NOT NULL,"\
                    "`acc_name` varchar(40) NOT NULL,"\
                    "`acc_peak_bw` varchar(40) NOT NULL,"\
                    "PRIMARY KEY (`id`)"\
                    ") ENGINE=InnoDB  DEFAULT CHARSET=latin1"
            cursor.execute(query1)
            cursor.execute(query2)
        except Error as e:
            print e

        finally:
            cursor.close()


    def insert_into_acc_type_list(self):
        cursor = self.conn.cursor()
        query = "INSERT  INTO `acc_type_list`("\
                "`id`,`acc_name`,"\
                "`acc_peak_bw`) "\
                "VALUES(%s,%s,%s)"
        try:

            args = list()
            i = 0
            for acc_name, acc_bw in self.acc_type_list.items():
                args.append((i, acc_name, acc_bw))
                i += 1

            for i in range(len(args)):
                cursor.execute(query, args[i])
                self.conn.commit()

        except Error as e:
            print e
        finally:
            cursor.close()


    def create_node_table(self):
        cursor = self.conn.cursor()
        try:
            query1 = "DROP TABLE IF EXISTS `fpga_nodes`"
            query2 = "CREATE TABLE `fpga_nodes`("\
                    "`id` int(11) NOT NULL,"\
                    "`node_ip` varchar(40) NOT NULL,"\
                    "`node_url` varchar(48) NOT NULL,"\
                    "`pcie_bw` varchar(40) NOT NULL,"\
                    "`if_fpga_available` int(1) NOT NULL,"\
                    "`section_num` int(2) NOT NULL,"\
                    "`roce_bw` varchar(40) NOT NULL,"\
                    "`roce_latency` varchar(40) NOT NULL,"\
                    "PRIMARY KEY(`id`)"\
                    ")ENGINE=InnoDB DEFAULT CHARSET=latin1"

            cursor.execute(query1)
            cursor.execute(query2)


        except Error as e:
            print e

        finally:
            cursor.close()

    def insert_into_fpga_node(self):
        cursor = self.conn.cursor()
        query = "INSERT INTO `fpga_nodes`"\
                "(`id`,`node_ip`,`node_url`,`pcie_bw`,"\
                "`if_fpga_available`,`section_num`,"\
                "`roce_bw`, `roce_latency`) "\
                "VALUES(%s, %s, %s, %s, %s, %s, %s, %s)"
        try:
            for i in range(self.total_node_num):
                id = str(i)
                node_ip = "10.0.0.5"+str(i)
                node_url ="http://"+node_ip+":"+self.url_port
                pcie_bw = str(2.8)
                if i<1:
                    if_fpga_available = 1
                    section_num = self.each_section_num
                else:
                    if_fpga_available = 0
                    section_num = 0
                roce_bw = str(40/8)
                roce_latency = str(12)
                query_args = (id, node_ip, node_url,
                              pcie_bw, if_fpga_available,
                              section_num,roce_bw, roce_latency)
                cursor.execute(query, query_args)
                self.conn.commit()
        except Error as e:
            print e
        finally:
            cursor.close()



    def create_section_table(self):
        cursor = self.conn.cursor()
        try:
            query1 = "DROP TABLE IF EXISTS `fpga_resources`"
            query2 = "CREATE TABLE `fpga_resources` ("\
                    "`id` int(11) NOT NULL,"\
                    "`node_ip` varchar(40) NOT NULL,"\
                    "`port_id` varchar(40) NOT NULL,"\
                    "`acc_name` varchar(40),"\
                    "PRIMARY KEY(`id`))ENGINE=InnoDB DEFAULT CHARSET=latin1"
            cursor.execute(query1)
            cursor.execute(query2)
        except Error as e:
            print e

        finally:
            cursor.close()


    def insert_into_fpga_section(self):
        cursor = self.conn.cursor()
        query = "insert  into `fpga_resources`("\
                "`id`,`node_ip`,"\
                "`port_id`,"\
                "`acc_name`)"\
                "VALUES (%s,%s,%s,%s)"
        try:
            i = 0
            for node_index in range(self.total_node_num):
                if node_index < 1:
                    for sec_index in range(self.each_section_num):
                        for acc_name, acc_bw in self.acc_type_list.items():
                            id = str(i+1)
                            i += 1
                            node_ip = "10.0.0.5"+str(node_index)
                            port_id = str(sec_index)
                            query_args = (id, node_ip, port_id, acc_name)
                            cursor.execute(query,query_args)
                            self.conn.commit()

        except Error as e:
            print e
        finally:
            cursor.close()

if __name__ == "__main__":
    system_initiator = SystemInitiator()
    system_initiator.create_acc_table()
    system_initiator.insert_into_acc_type_list()
    system_initiator.create_node_table()
    system_initiator.insert_into_fpga_node()
    system_initiator.create_section_table()
    system_initiator.insert_into_fpga_section()


