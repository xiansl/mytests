#! /bin/bash
algorithm=$1
mean=$2
echo "using ${algorithm}"
mkdir -p logfile$mean/
rm -rf logfile$mean/${algorithm}
mkdir logfile$mean/${algorithm}
../scheduler/./new_scheduler.py 10.0.0.50 9000 ${algorithm} >> logfile$mean/${algorithm}/${algorithm}.log  
