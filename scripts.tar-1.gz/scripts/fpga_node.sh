#! /bin/bash
job_num=$1
mean=$2
hr=$3
min=$4
addr=$5
./set_real_job.py $job_num $mean 
.././xmlrpclib_server.py -a $addr -p 8000 & 
./execute_job.sh $hr $min & 


