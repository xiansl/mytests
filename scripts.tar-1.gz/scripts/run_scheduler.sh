#! /bin/bash
algorithm=$1
mean=$2
echo "using ${algorithm}"
mkdir -p logfile$mean/
rm -rf logfile$mean/${algorithm}
mkdir logfile$mean/${algorithm}
../scheduler/./new_scheduler.py r1 9000 ${algorithm} >> logfile$mean/${algorithm}/${algorithm}.log  
