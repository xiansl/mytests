#! /bin/bash
algorithm=$1
mean=$2
job_num=$3
hr=$4
min=$5
./run_scheduler.sh $algorithm $mean &
for ((i=1;i<=5;i++)); do
{
	addr=r$i
	ssh r$i "cd /home/900/lxs900/zzd/fpga_platform/scripts ; ./fpga_node.sh $job_num $mean $hr $min $addr"
}&
done

