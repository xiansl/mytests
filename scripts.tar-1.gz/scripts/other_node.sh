#! /bin/bash
job_num=$1
mean=$2
hr=$3
min=$4
./set_real_job.py $job_num $mean 
./execute_job.sh $hr $min & 
