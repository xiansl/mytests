#! /bin/bash
algorithm=$1
mean=$2
job_num=$3
hr=$4
min=$5
./run_scheduler.sh $algorithm $mean &
for ((i=1;i<=10;i++)); do
{
    if [ $i -le 5 ];then 
		addr=r$i
		ssh r$i "cd /home/900/lxs900/zzd/fpga_platform/ ; ./xmlrpclib_server.py -a $addr -p 8000 &"
    else 
		ssh r$i "cd /home/900/lxs900/zzd/fpga_platform/scripts ; ./other_node.sh $job_num $mean $hr $min"
    fi
}&
done

