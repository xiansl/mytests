#! /bin/bash
CURRENT=$(date +%T)
echo $CURRENT

