#! /bin/bash
node=$1
echo "test on node $node"
.././test1.sh &
.././test2.sh &
