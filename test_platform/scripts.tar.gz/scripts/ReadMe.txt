run login.sh with the following parameters:

pattern=$1
algorithm=$2
mean=$3

job_num=$4
hr=$5
min=$6

total_nodes=$7
fpga_nodes=$8

first, you need to fill out fpga_node.txt
then, run ./login.sh Local LOCALITY2 500 10 Hr Min 4 2
