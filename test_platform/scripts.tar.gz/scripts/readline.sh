#! /bin/bash

ssh localhost "ls ;\
	ls -a ;\
	ls -t"
