#! /bin/bash
pattern=$1
algorithm=$2
mean=$3
node=$4
echo "using ${algorithm}, mean = ${mean}, pattern = ${pattern}"
mkdir -p logfile/$pattern/f$mean
rm -rf logfile/$pattern/f$mean/${algorithm}
mkdir logfile/$pattern/f$mean/${algorithm}
./final_scheduler.py $node 9000 ${algorithm} >> logfile/$pattern/f$mean/${algorithm}/${algorithm}.log  
