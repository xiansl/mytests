#! /bin/bash
pattern=$1
algorithm=$2
mean=$3

job_num=$4
hr=$5
min=$6

total_nodes=$7
fpga_nodes=$8

chmod +x *.sh
chmod +x *.py


./run_scheduler.sh $algorithm $mean $pattern&


Nodes=($(awk '{print $1}' fpga_node.txt)) #Nodes stores all the hostnames 
unset Nodes[0] #remove the first item "hostname"

echo "pattern=$pattern"

if [[ $pattern = "Local" ]]
then

	for node in ${nodes[@]:1:$fpga_nodes}
	do	
		echo $node
		ssh $node "cd /home/900/lxs900/zzd/fpga_platform/scripts ; \
			./fpga_node.sh $job_num $mean $hr $min $node" &

		#ssh localhost "cd fpga_platform/execute_scripts/scripts/ ; ./test.sh $node" &   
	done
	

elif [[ $pattern = "Remote" ]]
then

	for node in ${Nodes[@]:1:$fpga_nodes}
	do
		ssh $node "cd /home/900/lxs900/zzd/fpga_platform/scripts ; \
			.././xmlrpclib_server.py -a $node -p 8000" &
	done

	next_node=$fpga_nodes+1
	for node in ${Nodes[@]:$next_node}
	do
		echo $node
		ssh $node "cd /home/900/lxs900/zzd/fpga_platform/scripts ; \
			./other_node.sh -$job_num $mean $hr $min" 
	done

else
	echo $pattern
	for node in ${nodes[@]:1:$fpga_nodes}
	do	
		echo $node
		ssh $node "cd /home/900/lxs900/zzd/fpga_platform/scripts ; \
			./fpga_node.sh $job_num $mean $hr $min $node" &

		#ssh localhost "cd fpga_platform/execute_scripts/scripts/ ; ./test.sh $node" &   
	done

	next_node=$fpga_nodes+1
	for node in ${Nodes[@]:$next_node}
	do
		echo $node
		ssh $node "cd /home/900/lxs900/zzd/fpga_platform/scripts ; \
			./other_node.sh -$job_num $mean $hr $min" 
	done
fi
